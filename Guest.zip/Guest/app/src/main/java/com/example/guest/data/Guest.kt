package com.example.guest.data

data class Guest(
    val id: Int = 0,
    val name: String,
    val email: String,
    val phone: String,
    val confirmed: Boolean = false,
)
